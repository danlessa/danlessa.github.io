
## Testing


```python
import matplotlib.pyplot as plt
import numpy as np
```


```python
plt.hist(np.random.rand(500))
```




    (array([38., 45., 63., 36., 46., 50., 52., 59., 55., 56.]),
     array([7.14226462e-04, 1.00565991e-01, 2.00417755e-01, 3.00269520e-01,
            4.00121284e-01, 4.99973048e-01, 5.99824813e-01, 6.99676577e-01,
            7.99528342e-01, 8.99380106e-01, 9.99231871e-01]),
     <a list of 10 Patch objects>)




![png](output_2_1.png)



```python

```
